var express = require('express');
var app = express();
var bodyParser=require("body-parser"); 
const mongoose = require('mongoose'); 
mongoose.connect('mongodb://localhost:27017/Employee'); 
var db=mongoose.connection; 
db.on('error', console.log.bind(console, "Connection failed!")); 
app.use(bodyParser.json()); 
app.use(express.static('public')); 
app.use(bodyParser.urlencoded({ 
    extended: true
}));
app.set('view engine', 'ejs');
app.get('/', function(req, res) {
    res.render('index');
});
app.get('/employees', function(req, res) {
  db.collection("employees").find({}).toArray(function(err, result) {
    if (err) 
    throw err;
    res.render('employees',{result:result});
    db.close;
});});
app.post('/', function(req,res){ 
  var name = req.body.name;
  var email= req.body.email;
  var mobile=req.body.mobile;
  var city=req.body.city;  
  var write={"name": name,"email":email,"mobile":mobile,"city":city}
  db.collection('employees').insertOne(write,function(err, collection){ 
    if (err) throw err; 
    db.close;
});});
app.listen(3000);